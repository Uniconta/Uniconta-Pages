﻿using Uniconta.ClientTools.Controls;
using DevExpress.Xpf.Editors.Settings;
using DevExpress.Xpf.Grid.Native;
using System;
using System.Net;

using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace UnicontaClient.Pages.CustomPage
{
    public abstract class CorasauDataGridClient : CorasauDataGrid
    {
        public CorasauDataGridClient(IDataControlOriginationElement dataControlOriginationElement)
            : base(dataControlOriginationElement)
        {

        }
        public CorasauDataGridClient()
        {

        }
    }
    public class CorasauDataGridForeignKeyColumnClient : CorasauDataGridForeignKeyColumn
    {
    }

    public class CorasauGridLookupEditorClient : CorasauGridLookupEditor
    {
    }
    public class VariantEditorClient : VariantEditor
    {
    }
    public class CorasauDataGridTemplateColumnClient : CorasauDataGridTemplateColumn
    {
    }
    public class SearchLookUpStyleSettingsClient : SearchLookUpStyleSettings
    {
    }
}
